frontend-nanodegree-arcade-game
===============================
In order to start the game simply open the index.html file in an internet browser. The object of the game is to capture 
10 keys before you lose all 4 of your lives. Each time you capture a key you are returned to the starting point. 
You will use the directional arrows in order to navigate through the game board, but be careful not to fall off the map 
or you will lose a life. After the game is either won or lost you can refresh the browser window to play again. 